Paranat Thirawattanawong
README File for Programming Project v1 - Old Spice

The program starts off by importing all the necessary data that is required for determining the user's operating systems, importing data from the internet. 
Next, the positional arguments is created. This is mainly a set up for all the flags that the user can input.
The program then looks to determine whether the user wants the male or female version of the voice mail messages. This is done using the if-else loop.
The next part looks at the 10 digit phone number. An argument is set so that every character except for the number is ignored and whether the input value is 10 numbers or not. 
If the input isn't 10 numbers, it is invalid and the user is required to put in 10 numbers.
Then based on the numbers that were input in, the necessary MP3 files are downloaded in order.
The program then moved on to gather the reasons for the user not being able to call back. The argument is very similar to that of the 10 digit phone numbers except that there is no need for exactly 10 digits of numbers.
Instead, the selected reasons is listed with a corresponding number. This number will then tell python the MP3 that is needed to be downloaded.
Note that the reasons must be seperated into two lists, one for male and one for female, which is decided from the gender gathering arguments earlier.
The next part looks at the endings. This follow the same procedure as that of the reasons except with different lists.
Next, the information that has been inputted earlier are printed. The confirmation is then displayed.
Based on the user's selection, the program then uses the if-else loop to string together all the MP3 files that have been downloaded as well the beginning of the voicecall MP3 files.
Once done, all the files than have been previously downloaded are deleted except for the final voicemail MP3 file.
