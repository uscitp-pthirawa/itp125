# Paranat Thirawattanawong
# ITP 125 Programming Project v1 - Old Spice

import platform         # Python access the underlying platform's data
import urllib2          # Python fetches URLs - this will be used to find the Old Spice MP3 files
import os               # Python import the OS module, this is mainly for creating new directories
import argparse

# Set up argparse arguments
parser = argparse.ArgumentParser()
parser.add_argument("-g", "--gender", help="Must input male or female")
parser.add_argument("-n", "--number", help= "10 digit phone number")
parser.add_argument("-r", "--reasons", help = "selected reasons")
parser.add_argument("-e", "--endings", help = "selected endings")
parser.add_argument("-o", "--outputfile", help = "name of output file, do not include file extension")
args = parser.parse_args()

# A 'while True' loop will allow the user to restart program
program = True
while program == True:
# Following if-else loop will make it easier to call the correct OS command
    if platform.system() == 'Darwin':
        OS = 'Mac'
    else:
        OS = 'Windows'

# Asking for whether the user wants a male or female version. The code uses the if else loop.
    if args.gender:
        gender = args.gender
    else:
        gender_select = raw_input("Would you like the male or female version? Press 1 then enter for male and 2 then enter for female: ")
        while gender_select != '1' and gender_select !='2':
            gender_select = raw_input("That was not a valid input. Please input 1 for the male voice or 2 for the female voice: ")
        if gender_select == '1':
            gender = 'male'
        else:
            gender = 'female'

# Asking the user for the phone number. Parse it to get rid of everything but the numbers, and ensure it is 10 digits
    validnum = 'no'
    if args.number:
        phone_number = args.number
    else:
        phone_number= raw_input('Please enter your 10 digit phone number: ')
    while validnum == 'no':
        number = ''
        for char in phone_number:
            try:
                int(char)
                number += char
            except:
                pass
        if len(number) == 10:       # Ensure the number is 10 digits
            validnum = 'yes'
        else:
            print "That was not a valid number."
            phone_number = raw_input('Please enter your 10 digit phone number: ')
            continue
    # List of all the links for the MP3 file for the phone number
    # List starts from 0 and go to 9
    urlnumberlist = ['http://www-bcf.usc.edu/~chiso/itp125/project_version_1/0.mp3', 'http://www-bcf.usc.edu/~chiso/itp125/project_version_1/1.mp3', 'http://www-bcf.usc.edu/~chiso/itp125/project_version_1/2.mp3', 'http://www-bcf.usc.edu/~chiso/itp125/project_version_1/3.mp3', 'http://www-bcf.usc.edu/~chiso/itp125/project_version_1/4.mp3', 'http://www-bcf.usc.edu/~chiso/itp125/project_version_1/5.mp3', 'http://www-bcf.usc.edu/~chiso/itp125/project_version_1/6.mp3', 'http://www-bcf.usc.edu/~chiso/itp125/project_version_1/7.mp3', 'http://www-bcf.usc.edu/~chiso/itp125/project_version_1/8.mp3', 'http://www-bcf.usc.edu/~chiso/itp125/project_version_1/9.mp3']
    numberlist = []
    # Download the needed files
    for char in number:
        numberlist.append(urllib2.urlopen(urlnumberlist[int(char)]))

# List of the reasons that the user can pick. Split into 2 lists, one for female and one for male
    female_reasons = ['Ingesting my delicious Old Spice man smell', 'Listening to me reading romantic poetry while I make a bouquet of paper flowers from each read page', 'Enjoying a delicious lobster dinner I prepared just for her, while carrying her on my back safely through piranha infested waters', 'Being serenaded on the moon with a view of the earth, while surviving off the oxygen in my lungs via a passionate kiss', 'Riding a horse backwards with me']
    male_reasons = ['Building an orphanage for children with their bare hands while playing a sweet sweet lullaby for those children with two mallets against their ab xylophone', 'Cracking walnuts with their man-mind', 'Polishing their monocle smile', 'Ripping out mass loads of weights']

# Based on the initial gender selection, the if else loop would direct the user to the male or female's list of reasons
    if gender== 'male':
        reasons = male_reasons
    else:
        reasons= female_reasons
    if args.reasons:
        selected_reasons = args.reasons
    else:
        for i in range(0, len(reasons)):
            print '[%d] %s' %(i+1, reasons[i])
        selected_reasons = raw_input('Please choose one or more of the above reasons by inputting the number to the left of it. For example, a valid input is "1" or "12", no spaces: ')

# This is for checking the validity of the input above
    validreasons='no'
    while validreasons == 'no':
        reasons_list = []
        restart = False
        for char in selected_reasons:
            try:
                int(char)
            except:
                selected_reasons = raw_input('That was not a valid input. Please enter a valid input: ')
                restart = True
                break
            if int(char) > len(reasons):
                selected_reasons = raw_input('That was not a valid input. Please enter a valid input: ')
                restart = True
                break
        if restart:
            continue
        validreasons = 'yes'
        for char in selected_reasons:
            reasons_list.append(int(char))

# List of the links for the MP3 files for the reasoning. The URL links correspond to the reasons written above
    femalereasonURL = ['http://www-bcf.usc.edu/~chiso/itp125/project_version_1/f-r1-ingesting_old_spice.mp3', 'http://www-bcf.usc.edu/~chiso/itp125/project_version_1/f-r2-listening_to_reading.mp3', 'http://www-bcf.usc.edu/~chiso/itp125/project_version_1/f-r3-lobster_dinner.mp3', 'http://www-bcf.usc.edu/~chiso/itp125/project_version_1/f-r4-moon_kiss.mp3', 'http://www-bcf.usc.edu/~chiso/itp125/project_version_1/f-r5-riding_a_horse.mp3']
    malereasonURL = ['http://www-bcf.usc.edu/~chiso/itp125/project_version_1/m-r1-building.mp3', 'http://www-bcf.usc.edu/~chiso/itp125/project_version_1/m-r2-cracking_walnuts.mp3', 'http://www-bcf.usc.edu/~chiso/itp125/project_version_1/m-r3-polishing_monocole.mp3', 'http://www-bcf.usc.edu/~chiso/itp125/project_version_1/m-r4-ripping_weights.mp3']
    if gender == 'male':
        reasonURL = malereasonURL
    else:
        reasonURL = femalereasonURL
    reasonslist = []
    # Download the needed files
    for char in reasons_list:
        reasonslist.append(urllib2.urlopen(reasonURL[int(char)-1]))

# List of the endings, for male and female.
    female_endings = ["She'll get back to you as soon as she can", "Thanks for calling"]
    male_endings = ["I'm on a horse", "*Old Spice Jingle*", "I'm on a phone", "Swan Dive", "This voicemail is now done"]

    if gender == 'male':
        endings = male_endings
    else:
        endings = female_endings
    if args.endings:
        selected_endings = args.endings
    else:
        for i in range(0, len(endings)):
            print '[%d] %s' %(i+1, endings[i])
        selected_endings = raw_input('Please choose one or more of the above endings to your voicemail by inputting the number to the left of it. For example, a valid input is "1" or "12", no spaces: ')

# Put selected endings in list for easier processing and check validity
    validendings='no'
    while validendings == 'no':
        endings_list = []
        restart = False
        for char in selected_endings:
            try:
                int(char)
            except:
                selected_endings = raw_input('That was not a valid input. Please enter a valid input: ')
                restart = True
                break
            if int(char) > len(endings):
                selected_endings = raw_input('That was not a valid input. Please enter a valid input: ')
                restart = True
                break
        if restart:
            continue
        validendings = 'yes'
        for char in selected_endings:
            endings_list.append(int(char))

# List of endings URL, one for male and one for female
    maleendingsURL = ['http://www-bcf.usc.edu/~chiso/itp125/project_version_1/m-e1-horse.mp3', 'http://www-bcf.usc.edu/~chiso/itp125/project_version_1/m-e2-jingle.mp3', 'http://www-bcf.usc.edu/~chiso/itp125/project_version_1/m-e3-on_phone.mp3', 'http://www-bcf.usc.edu/~chiso/itp125/project_version_1/m-e4-swan_dive.mp3', 'http://www-bcf.usc.edu/~chiso/itp125/project_version_1/m-e5-voicemail.mp3']
    femaleendingURL = ['http://www-bcf.usc.edu/~chiso/itp125/project_version_1/f-e1-she_will_get_back_to_you.mp3', 'http://www-bcf.usc.edu/~chiso/itp125/project_version_1/f-e2-thanks_for_calling.mp3']
    if gender == 'male':
        endingURL = maleendingsURL
    else:
        endingURL = femaleendingURL
    # Download the needed files
    endingslist = []
    for char in endings_list:
        endingslist.append(urllib2.urlopen(endingURL[int(char)-1]))
# Display all input and ask for validation that it is correct
    if args.gender:
        program = False
    else:
        print 'The following information is what you have chosen:'
        print 'Gender: ' + gender
        print 'Phone number: ' + number
        print 'Reasons:'
        for num in selected_reasons:
            print '[%d] %s' %(int(num), reasons[int(num)-1])
            print 'Endings:'
        for num in selected_endings:
            print '[%d] %s' %(int(num), endings[int(num)-1])

        confirmation = raw_input("Is this information correct? Press 'y' for yes or 'n' for no: ")
        while confirmation != 'y' and confirmation != 'n':
            confirmation = raw_input("Invalid input. Is this information correct? Press 'y' for yes or 'n' for no: ")

    # Restart program from beginning of loop if user says info is incorrect
        if confirmation == 'n':
            print 'Information was incorrect. Prepare to restart.'
            continue
    #Do not restart loop if info was correct, and ask user to input their file name
        else:
            program = False
    if args.outputfile:
        file_name = args.outputfile
    else:
        file_name = raw_input('Please input what you would like to save your file as (Do not include the file extension): ')

# Write all necessary files to directory, then join them
    if gender == 'female':      # For female
        beginning1 = urllib2.urlopen("http://www-bcf.usc.edu/~chiso/itp125/project_version_1/f-b1-hello_caller.mp3")
        beginning2 = urllib2.urlopen("http://www-bcf.usc.edu/~chiso/itp125/project_version_1/f-b2-lady_at.mp3")
        reason0 = urllib2.urlopen("http://www-bcf.usc.edu/~chiso/itp125/project_version_1/f-r0.1-unable_to_take_call.mp3")
        reason01 = urllib2.urlopen("http://www-bcf.usc.edu/~chiso/itp125/project_version_1/f-r0.2-she_is_busy.mp3")
    else:       # For male
        beginning1 = urllib2.urlopen("http://www-bcf.usc.edu/~chiso/itp125/project_version_1/m-b1-hello.mp3")
        beginning2 = urllib2.urlopen("http://www-bcf.usc.edu/~chiso/itp125/project_version_1/m-b2-have_dialed.mp3")
        reason0 = urllib2.urlopen("http://www-bcf.usc.edu/~chiso/itp125/project_version_1/m-r0-cannot_come_to_phone.mp3")

    # Write the beginning files
    b1 = open('b1.mp3', 'wb')
    b1.write(beginning1.read())
    b1.close()
    b2 = open('b2.mp3','wb')
    b2.write(beginning2.read())
    b2.close()
    r0 = open('r0.mp3','wb')
    r0.write(reason0.read())
    r0.close()
    if gender == 'female':
        r01 = open('r01.mp3','wb')
        r01.write(reason01.read())
        r01.close()

    # Begin to construct string for final command
    # Join mp3 files: command = copy /b track1.mp3 + space.mp3 + track2.mp3  c:\new.mp3
    commandstring = 'copy /b b1.mp3 + b2.mp3 '

    # Write the numbers, reasons, and endings
    i = 1
    for sound in numberlist:
        soundfile = open(str(i) + '.mp3', 'wb')
        soundfile.write(sound.read())
        soundfile.close()
        commandstring = commandstring + '+ ' + str(i) + '.mp3 '
        i = i +1
    commandstring = commandstring + '+ r0.mp3 '
    if gender == 'female':
        commandstring = commandstring + '+ r01.mp3 '
    for reason in reasonslist:
        soundfile = open(str(i) + '.mp3', 'wb')
        soundfile.write(reason.read())
        soundfile.close()
        commandstring = commandstring + '+ ' + str(i) + '.mp3 '

        i = i +1
    for ending in endingslist:
        soundfile =open(str(i) + '.mp3', 'wb')
        soundfile.write(ending.read())
        soundfile.close()
        commandstring = commandstring +'+ ' +  str(i) + '.mp3 '
        i = i + 1

    # Write the generic signoff for the male
    if gender == 'male':
        returncall = urllib2.urlopen("http://www-bcf.usc.edu/~chiso/itp125/project_version_1/m-leave_a_message.mp3")
        rc = open('rc.mp3', 'wb')
        rc.write(returncall.read())
        rc.close()
        signoff =urllib2.urlopen("http://www-bcf.usc.edu/~chiso/itp125/project_version_1/m-youre_welcome.mp3")
        gb = open('gb.mp3', 'wb')
        gb.write(signoff.read())
        gb.close()
        commandstring = commandstring + '+ rc.mp3 + gb.mp3 '

    # Make final string for command prompt entry to splice mp3 together
    commandstring = commandstring + file_name + '.mp3'
    if OS == 'Windows':
            os.system(commandstring)
    else:
            commandstring = commandstring.replace('+', '')
            commandstring = commandstring.replace('copy', '', 1)
            commandstring = commandstring.replace('/b', '',1)
            commandstring = commandstring.replace(file_name + '.mp3','',1)
            outputstring = commandstring
            commandstring = 'cat' + commandstring + ' > ' + file_name + '.mp3'
            os.system(commandstring)

    # Delete all files other than final voicemail
    filelist = [ f for f in os.listdir(".") if f.endswith(".mp3") and f != file_name +".mp3"]
    for f in filelist:
        os.remove(f)

    # Create string for output file and output file itself
    if OS == 'Mac':
        outputfile = open('outputfile', 'wb')
        outputfile.write(gender + ' ' + number + ' '+ outputstring)
        outputfile.close()
    else:
        outputstring = commandstring.replace('+', '')
        outputstring = outputstring.replace('copy', '', 1)
        outputstring = outputstring.replace('/b', '',1)
        outputstring = outputstring.replace(file_name + '.mp3','',1)
        outputfile = open('outputfile', 'wb')
        outputfile.write(gender + ' ' + number + outputstring)
        outputfile.close()
